from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = False
config.General.transferOutputs = True
config.General.workArea = 'ppref_Efficiecny'
config.General.requestName = 'Pythia_LowPU_NoTrigger_5p36TeV_ptResoAfterpT10GeV'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'run_PPRef_cfg.py'
config.section_('Data')
config.Data.outputDatasetTag = 'Pythia_LowPU_NoTrigger_5p36TeV_ptResoAfterpT10GeV'
config.Data.inputDataset = '/Pythia8_LowPU_0p5MEvents_TuneCP5_5360GeV/rpradhan-PrivatePythia8_LowPU_0p5MEvents_RecoDebug-7d0fd9a913ab722b2353469d41166019/USER'
config.Data.splitting = 'FileBased'
config.Data.totalUnits = -1
config.Data.unitsPerJob = 10
config.Data.inputDBS = 'phys03'
config.Data.outLFNDirBase = '/store/group/phys_heavyions/rpradhan/Tracking_ppref_5p36TeV'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
