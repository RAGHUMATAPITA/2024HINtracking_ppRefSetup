from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'ppref_Efficiecny'
config.General.requestName = 'Pythia_NoPU_NoTrigger_TuneCP5_QCD_ptHat15_5p36TeV_ptResoAfterpT10GeV'
config.General.transferOutputs = True
config.General.transferLogs = False
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'run_PPRef_cfg.py'
config.section_('Data')
config.Data.outLFNDirBase = '/store/group/phys_heavyions/rpradhan/Tracking_ppref_5p36TeV'
config.Data.unitsPerJob = 10
config.Data.splitting = 'FileBased'
config.Data.inputDataset = '/Pythia8_NoPU_0p5MEvents_TuneCP5_QCD_ptHat15_5360GeV/rpradhan-PrivatePythia8_NoPU_0p5MEvents_TuneCP5_QCD_ptHat15_RecoDebug-7d0fd9a913ab722b2353469d41166019/USER'
config.Data.inputDBS = 'phys03'
config.Data.outputDatasetTag = 'Pythia_NoPU_TuneCP5_QCD_ptHat15_NoTrigger_5p36TeV_ptResoAfterpT10GeV'
config.Data.totalUnits = -1
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
