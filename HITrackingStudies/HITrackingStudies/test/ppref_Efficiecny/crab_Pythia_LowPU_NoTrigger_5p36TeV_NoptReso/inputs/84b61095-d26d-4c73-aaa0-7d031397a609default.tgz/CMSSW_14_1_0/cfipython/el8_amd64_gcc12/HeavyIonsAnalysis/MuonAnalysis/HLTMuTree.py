import FWCore.ParameterSet.Config as cms

def HLTMuTree(**kwargs):
  mod = cms.EDAnalyzer('HLTMuTree',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
