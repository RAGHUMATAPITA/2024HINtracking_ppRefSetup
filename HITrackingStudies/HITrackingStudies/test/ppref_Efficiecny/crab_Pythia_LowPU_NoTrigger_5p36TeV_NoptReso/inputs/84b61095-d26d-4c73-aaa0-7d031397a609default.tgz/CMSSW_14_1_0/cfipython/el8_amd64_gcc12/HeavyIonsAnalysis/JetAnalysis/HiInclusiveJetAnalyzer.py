import FWCore.ParameterSet.Config as cms

def HiInclusiveJetAnalyzer(**kwargs):
  mod = cms.EDAnalyzer('HiInclusiveJetAnalyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
