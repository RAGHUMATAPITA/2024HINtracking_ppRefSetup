import FWCore.ParameterSet.Config as cms

def L1UpgradeFlatTreeProducer(**kwargs):
  mod = cms.EDAnalyzer('L1UpgradeFlatTreeProducer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
