import FWCore.ParameterSet.Config as cms

def ZDCTreeProducer(**kwargs):
  mod = cms.EDAnalyzer('ZDCTreeProducer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
