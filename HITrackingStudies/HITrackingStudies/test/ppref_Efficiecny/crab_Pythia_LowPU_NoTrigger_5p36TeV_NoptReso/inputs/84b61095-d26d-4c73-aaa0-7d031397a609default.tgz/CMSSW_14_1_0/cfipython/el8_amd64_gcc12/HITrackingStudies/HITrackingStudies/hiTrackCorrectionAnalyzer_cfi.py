import FWCore.ParameterSet.Config as cms

from .HITrackCorrectionAnalyzer import HITrackCorrectionAnalyzer

hiTrackCorrectionAnalyzer = HITrackCorrectionAnalyzer()
