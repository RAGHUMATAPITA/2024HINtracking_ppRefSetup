import FWCore.ParameterSet.Config as cms

def EmbedMCinMuons(**kwargs):
  mod = cms.EDProducer('EmbedMCinMuons',
    muons = cms.InputTag('unpackedMuons'),
    matchedGen = cms.InputTag('muonMatch'),
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
