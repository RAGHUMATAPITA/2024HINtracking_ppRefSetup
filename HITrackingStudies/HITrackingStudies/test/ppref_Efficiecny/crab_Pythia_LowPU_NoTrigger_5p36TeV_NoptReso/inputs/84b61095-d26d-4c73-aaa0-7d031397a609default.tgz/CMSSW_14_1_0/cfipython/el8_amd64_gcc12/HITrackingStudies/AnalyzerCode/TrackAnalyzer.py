import FWCore.ParameterSet.Config as cms

def TrackAnalyzer(**kwargs):
  mod = cms.EDAnalyzer('TrackAnalyzer',
    trackPtMin = cms.double(0),
    simTrackPtMin = cms.double(0),
    doTrack = cms.bool(True),
    doTrackExtra = cms.bool(False),
    vertexSrc = cms.vstring('offlinePrimaryVertices'),
    trackSrc = cms.InputTag('generalTracks'),
    mvaSrc = cms.InputTag('generalTracks', 'MVAVals'),
    particleSrc = cms.InputTag('genParticles'),
    pfCandSrc = cms.InputTag('particleFlow'),
    beamSpotSrc = cms.InputTag('offlineBeamSpot'),
    centralitySrc = cms.InputTag('centralityBin', 'HFTowers'),
    doPFMatching = cms.bool(True),
    doSimTrack = cms.bool(True),
    doSimVertex = cms.bool(True),
    useCentrality = cms.bool(False),
    doHighestPtVertex = cms.bool(True),
    fillSimTrack = cms.bool(True),
    doDeDx = cms.bool(False),
    doDebug = cms.bool(False),
    useQuality = cms.bool(False),
    qualityStrings = cms.vstring(
      'highPurity',
      'tight',
      'loose'
    ),
    tpFakeSrc = cms.InputTag('mix', 'MergedTrackTruth'),
    tpEffSrc = cms.InputTag('mix', 'MergedTrackTruth'),
    associatorMap = cms.InputTag('tpRecoAssocGeneralTracks'),
    doMVA = cms.bool(False),
    doTrackVtxWImpPar = cms.bool(True),
    trackVtxMaxDistance = cms.double(3),
    qualityString = cms.string('highPurity'),
    fiducialCut = cms.bool(False),
    tpVtxSrc = cms.InputTag('mix', 'MergedTrackTruth'),
    packedCandSrc = cms.InputTag('packedPFCandidates'),
    lostTracksSrc = cms.InputTag('lostTracks'),
    chi2Map = cms.InputTag('packedPFCandidateTrackChi2'),
    chi2MapLost = cms.InputTag('lostTrackChi2'),
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
