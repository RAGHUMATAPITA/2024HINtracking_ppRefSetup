import FWCore.ParameterSet.Config as cms

def HiEvtAnalyzer(**kwargs):
  mod = cms.EDAnalyzer('HiEvtAnalyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
