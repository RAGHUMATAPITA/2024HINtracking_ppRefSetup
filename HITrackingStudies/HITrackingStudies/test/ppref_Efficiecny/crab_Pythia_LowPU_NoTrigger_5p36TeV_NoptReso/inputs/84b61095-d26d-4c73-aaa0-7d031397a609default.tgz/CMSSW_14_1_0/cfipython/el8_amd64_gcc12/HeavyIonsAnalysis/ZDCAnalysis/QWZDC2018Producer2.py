import FWCore.ParameterSet.Config as cms

def QWZDC2018Producer2(**kwargs):
  mod = cms.EDProducer('QWZDC2018Producer2',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
