import FWCore.ParameterSet.Config as cms

from .TrackAnalyzer import TrackAnalyzer

trackAnalyzer = TrackAnalyzer()
