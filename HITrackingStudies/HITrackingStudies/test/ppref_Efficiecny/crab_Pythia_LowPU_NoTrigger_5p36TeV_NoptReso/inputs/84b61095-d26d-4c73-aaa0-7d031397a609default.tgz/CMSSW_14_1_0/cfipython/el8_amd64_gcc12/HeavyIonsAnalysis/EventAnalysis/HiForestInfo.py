import FWCore.ParameterSet.Config as cms

def HiForestInfo(**kwargs):
  mod = cms.EDAnalyzer('HiForestInfo',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
