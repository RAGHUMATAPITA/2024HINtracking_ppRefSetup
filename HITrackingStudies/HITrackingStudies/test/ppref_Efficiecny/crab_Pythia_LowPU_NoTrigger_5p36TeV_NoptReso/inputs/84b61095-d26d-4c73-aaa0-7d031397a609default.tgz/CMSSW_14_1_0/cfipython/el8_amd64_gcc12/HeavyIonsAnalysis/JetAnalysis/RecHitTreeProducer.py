import FWCore.ParameterSet.Config as cms

def RecHitTreeProducer(**kwargs):
  mod = cms.EDAnalyzer('RecHitTreeProducer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
