import FWCore.ParameterSet.Config as cms

def QWZDC2018RecHit(**kwargs):
  mod = cms.EDProducer('QWZDC2018RecHit',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
