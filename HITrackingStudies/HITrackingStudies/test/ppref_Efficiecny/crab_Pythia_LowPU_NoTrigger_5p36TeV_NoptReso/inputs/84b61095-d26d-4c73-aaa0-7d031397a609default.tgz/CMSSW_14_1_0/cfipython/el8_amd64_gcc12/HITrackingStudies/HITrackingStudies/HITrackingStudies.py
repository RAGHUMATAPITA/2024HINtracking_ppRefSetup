import FWCore.ParameterSet.Config as cms

def HITrackingStudies(**kwargs):
  mod = cms.EDAnalyzer('HITrackingStudies',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
