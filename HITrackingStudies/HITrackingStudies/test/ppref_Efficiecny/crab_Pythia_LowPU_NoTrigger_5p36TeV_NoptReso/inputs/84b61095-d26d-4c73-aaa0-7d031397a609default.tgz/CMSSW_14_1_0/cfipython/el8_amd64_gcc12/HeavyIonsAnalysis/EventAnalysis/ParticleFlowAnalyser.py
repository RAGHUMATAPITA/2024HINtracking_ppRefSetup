import FWCore.ParameterSet.Config as cms

def ParticleFlowAnalyser(**kwargs):
  mod = cms.EDAnalyzer('ParticleFlowAnalyser',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
