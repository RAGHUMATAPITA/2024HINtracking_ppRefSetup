import FWCore.ParameterSet.Config as cms

def TriggerAnalyzer(**kwargs):
  mod = cms.EDAnalyzer('TriggerAnalyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for k,v in kwargs.items():
    setattr(mod, k, v)
  return mod
